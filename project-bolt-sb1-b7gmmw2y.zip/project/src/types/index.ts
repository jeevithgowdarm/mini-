export type RoomStyle = 'modern' | 'minimalist' | 'scandinavian' | 'industrial' | 'bohemian' | 'coastal';

export interface Design {
  id: string;
  imageUrl: string;
  style: RoomStyle;
}