import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { ImageUploader } from './components/ImageUploader';
import { StylePicker } from './components/StylePicker';
import { GeneratedDesigns } from './components/GeneratedDesigns';
import { LoadingState } from './components/LoadingState';
import { generateDesigns } from './utils/designGenerator';
import type { RoomStyle, Design } from './types';

function App() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<RoomStyle | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [designs, setDesigns] = useState<Design[]>([]);

  const handleImageUpload = (imageUrl: string) => {
    setUploadedImage(imageUrl);
    setDesigns([]);
    setSelectedStyle(null);
  };

  const handleStyleSelect = async (style: RoomStyle) => {
    setSelectedStyle(style);
    setIsGenerating(true);
    
    try {
      const newDesigns = await generateDesigns(uploadedImage!, style);
      setDesigns(newDesigns);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (!selectedStyle || !uploadedImage) return;
    setIsGenerating(true);
    
    try {
      const newDesigns = await generateDesigns(uploadedImage, selectedStyle);
      setDesigns(newDesigns);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    setUploadedImage(null);
    setSelectedStyle(null);
    setDesigns([]);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-emerald-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
              SpaceVision
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Transform your space with endless design possibilities
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {!uploadedImage ? (
            <ImageUploader key="uploader" onImageUpload={handleImageUpload} />
          ) : (
            <motion.div
              key="content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold">Choose Your Style</h2>
                <button
                  onClick={handleReset}
                  className="px-4 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                >
                  Upload New Image
                </button>
              </div>

              <StylePicker
                selectedStyle={selectedStyle}
                onStyleSelect={handleStyleSelect}
              />

              <AnimatePresence mode="wait">
                {isGenerating ? (
                  <LoadingState key="loading" />
                ) : designs.length > 0 ? (
                  <GeneratedDesigns
                    key="designs"
                    designs={designs}
                    originalImage={uploadedImage}
                    onRegenerate={handleRegenerate}
                  />
                ) : null}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;