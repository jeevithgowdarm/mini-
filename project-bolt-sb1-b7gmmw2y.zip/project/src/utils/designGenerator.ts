import { STYLE_IMAGES } from '../constants';
import type { RoomStyle, Design } from '../types';

function getRandomImages(style: RoomStyle, count: number = 6): string[] {
  const styleImages = STYLE_IMAGES[style];
  const images: string[] = [];
  
  for (let i = 0; i < count; i++) {
    const randomIndex = Math.floor(Math.random() * styleImages.length);
    const baseUrl = styleImages[randomIndex];
    const width = 800 + Math.floor(Math.random() * 400); // Random width between 800-1200
    const height = 600 + Math.floor(Math.random() * 300); // Random height between 600-900
    const imageUrl = `${baseUrl}?w=${width}&h=${height}&fit=crop&q=80`;
    images.push(imageUrl);
  }
  
  return images;
}

export async function generateDesigns(originalImage: string, style: RoomStyle): Promise<Design[]> {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const images = getRandomImages(style);
  
  return images.map((imageUrl, index) => ({
    id: `${style}-${Date.now()}-${index}`,
    imageUrl,
    style
  }));
}