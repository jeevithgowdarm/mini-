import type { RoomStyle } from '../types';

// Collection of curated images for each style
const styleImages = {
  modern: [
    'https://images.unsplash.com/photo-1600585154526-990dced4db0d',
    'https://images.unsplash.com/photo-1600573472591-ee6981cf83cc',
    'https://images.unsplash.com/photo-1600566752355-35792bedcfea'
  ],
  minimalist: [
    'https://images.unsplash.com/photo-1598928506311-c55ded91a20c',
    'https://images.unsplash.com/photo-1598928636135-d146006ff4be',
    'https://images.unsplash.com/photo-1598928506311-c55ded91a20c'
  ],
  scandinavian: [
    'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf',
    'https://images.unsplash.com/photo-1586023492125-27b2c045efd7',
    'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92'
  ],
  industrial: [
    'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d',
    'https://images.unsplash.com/photo-1600607687644-c7171b42498d',
    'https://images.unsplash.com/photo-1600607688969-a5bfcd646154'
  ],
  contemporary: [
    'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0',
    'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87',
    'https://images.unsplash.com/photo-1600210492493-0946911123ea'
  ]
};

export const getRandomStyleImage = (style: RoomStyle, dimensions: { width: number; height: number }) => {
  const images = styleImages[style];
  const randomIndex = Math.floor(Math.random() * images.length);
  const baseUrl = images[randomIndex];
  return `${baseUrl}?w=${dimensions.width}&h=${dimensions.height}&fit=crop&q=80`;
};

export const getImageDimensions = (file: File): Promise<{ width: number; height: number }> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(img.src);
      resolve({ width: img.width, height: img.height });
    };
    img.src = URL.createObjectURL(file);
  });
};