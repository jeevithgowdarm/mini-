import type { RoomStyle } from '../types';

export const ROOM_STYLES = [
  {
    id: 'modern' as RoomStyle,
    name: 'Modern',
    description: 'Clean lines and contemporary aesthetics'
  },
  {
    id: 'minimalist' as RoomStyle,
    name: 'Minimalist',
    description: 'Simple, uncluttered, and purposeful design'
  },
  {
    id: 'scandinavian' as RoomStyle,
    name: 'Scandinavian',
    description: 'Light, airy, and functional spaces'
  },
  {
    id: 'industrial' as RoomStyle,
    name: 'Industrial',
    description: 'Raw materials with urban sophistication'
  },
  {
    id: 'bohemian' as RoomStyle,
    name: 'Bohemian',
    description: 'Eclectic and artistic expression'
  },
  {
    id: 'coastal' as RoomStyle,
    name: 'Coastal',
    description: 'Beach-inspired relaxed living'
  }
];

export const STYLE_IMAGES = {
  modern: [
    'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0',
    'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
    'https://images.unsplash.com/photo-1600210491369-e753d80a41f3'
  ],
  minimalist: [
    'https://images.unsplash.com/photo-1598928506311-c55ded91a20c',
    'https://images.unsplash.com/photo-1598928636135-d146006ff4be',
    'https://images.unsplash.com/photo-1600566752355-35792bedcfea'
  ],
  scandinavian: [
    'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf',
    'https://images.unsplash.com/photo-1586023492125-27b2c045efd7',
    'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92'
  ],
  industrial: [
    'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d',
    'https://images.unsplash.com/photo-1600607687644-c7171b42498d',
    'https://images.unsplash.com/photo-1600607688969-a5bfcd646154'
  ],
  bohemian: [
    'https://images.unsplash.com/photo-1600573472591-ee6981cf83cc',
    'https://images.unsplash.com/photo-1600585154526-990dced4db0d',
    'https://images.unsplash.com/photo-1600573472592-401b489a3cdc'
  ],
  coastal: [
    'https://images.unsplash.com/photo-1600573472592-401b489a3cdc',
    'https://images.unsplash.com/photo-1600573472591-ee6981cf83cc',
    'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0'
  ]
};