import React from 'react';
import { motion } from 'framer-motion';
import type { RoomStyle } from '../types';
import { ROOM_STYLES } from '../constants';

interface StylePickerProps {
  selectedStyle: RoomStyle | null;
  onStyleSelect: (style: RoomStyle) => void;
}

export function StylePicker({ selectedStyle, onStyleSelect }: StylePickerProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {ROOM_STYLES.map((style) => (
        <motion.button
          key={style.id}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onStyleSelect(style.id)}
          className={`
            relative p-4 rounded-lg transition-all overflow-hidden
            ${selectedStyle === style.id
              ? 'ring-2 ring-emerald-400 bg-gray-800'
              : 'bg-gray-800/50 hover:bg-gray-800'
            }
          `}
        >
          <div className="relative z-10">
            <h3 className="text-lg font-medium">{style.name}</h3>
            <p className="mt-1 text-sm text-gray-400">{style.description}</p>
          </div>
          {selectedStyle === style.id && (
            <motion.div
              layoutId="selectedStyle"
              className="absolute inset-0 bg-gradient-to-r from-emerald-400/10 to-blue-500/10"
              transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
            />
          )}
        </motion.button>
      ))}
    </div>
  );
}