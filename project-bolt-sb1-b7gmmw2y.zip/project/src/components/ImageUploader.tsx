import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface ImageUploaderProps {
  onImageUpload: (imageUrl: string) => void;
}

export function ImageUploader({ onImageUpload }: ImageUploaderProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        onImageUpload(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, [onImageUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto"
    >
      <div
        {...getRootProps()}
        className={`
          p-12 border-2 border-dashed rounded-xl cursor-pointer transition-all
          ${isDragActive 
            ? 'border-emerald-400 bg-emerald-400/10' 
            : 'border-gray-600 hover:border-emerald-400/50 hover:bg-gray-800/50'
          }
        `}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-6">
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-emerald-400 to-blue-500 rounded-full blur opacity-75" />
            <div className="relative bg-gray-900 rounded-full p-4">
              <ImageIcon className="w-12 h-12 text-emerald-400" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-xl font-medium text-gray-200">
              {isDragActive ? 'Drop your room image here' : 'Upload your room image'}
            </p>
            <p className="mt-2 text-gray-400">
              Drag and drop or click to select
            </p>
          </div>
          <div className="flex gap-4 text-sm text-gray-500">
            <span>JPG</span>
            <span>PNG</span>
            <span>Max 10MB</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}