import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';
import { motion } from 'framer-motion';

interface RoomUploaderProps {
  onImageUpload: (file: File) => void;
}

export function RoomUploader({ onImageUpload }: RoomUploaderProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onImageUpload(acceptedFiles[0]);
    }
  }, [onImageUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-xl mx-auto"
    >
      <div
        {...getRootProps()}
        className={`p-8 border-2 border-dashed rounded-xl cursor-pointer transition-colors
          ${isDragActive 
            ? 'border-purple-500 bg-purple-500/10' 
            : 'border-gray-600 hover:border-purple-500 bg-gray-800/50'}`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-4">
          <Upload className="w-12 h-12 text-purple-500" />
          <div className="text-center">
            <p className="text-lg font-medium text-gray-200">
              {isDragActive ? 'Drop your room image here' : 'Drag & drop your room image'}
            </p>
            <p className="mt-2 text-sm text-gray-400">
              or click to select a file
            </p>
          </div>
          <p className="text-xs text-gray-500">
            Supports: JPG, JPEG, PNG
          </p>
        </div>
      </div>
    </motion.div>
  );
}