import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeftRight, Download } from 'lucide-react';
import clsx from 'clsx';

interface ResultViewProps {
  beforeImage: string;
  afterImage: string;
}

export function ResultView({ beforeImage, afterImage }: ResultViewProps) {
  const [isComparing, setIsComparing] = useState(false);
  const [comparePosition, setComparePosition] = useState(50);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isComparing) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    setComparePosition(x);
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = afterImage;
    link.download = 'transformed-room.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-4xl mx-auto"
    >
      <div
        className="relative h-[500px] rounded-lg overflow-hidden cursor-move"
        onMouseDown={() => setIsComparing(true)}
        onMouseUp={() => setIsComparing(false)}
        onMouseLeave={() => setIsComparing(false)}
        onMouseMove={handleMouseMove}
      >
        <div className="absolute inset-0">
          <img
            src={afterImage}
            alt="Transformed room"
            className="w-full h-full object-cover"
          />
        </div>
        <div
          className="absolute inset-0"
          style={{ clipPath: `inset(0 ${100 - comparePosition}% 0 0)` }}
        >
          <img
            src={beforeImage}
            alt="Original room"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div
          className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize"
          style={{ left: `${comparePosition}%` }}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white rounded-full p-2">
            <ArrowLeftRight className="w-4 h-4 text-gray-900" />
          </div>
        </div>

        <div className={clsx(
          "absolute bottom-4 left-4 right-4 flex justify-between items-center",
          "bg-black/70 backdrop-blur-sm rounded-lg p-3"
        )}>
          <div className="flex gap-4">
            <span className="text-sm">Before</span>
            <span className="text-sm">After</span>
          </div>
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 px-3 py-1 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm">Download</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}