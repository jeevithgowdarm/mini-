import React from 'react';
import { motion } from 'framer-motion';
import Masonry from 'react-masonry-css';
import { RefreshCw } from 'lucide-react';
import type { Design } from '../types';

interface GeneratedDesignsProps {
  designs: Design[];
  originalImage: string;
  onRegenerate: () => void;
}

export function GeneratedDesigns({ designs, originalImage, onRegenerate }: GeneratedDesignsProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-medium">Generated Designs</h3>
        <button
          onClick={onRegenerate}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          Generate More
        </button>
      </div>

      <Masonry
        breakpointCols={{
          default: 3,
          1100: 2,
          700: 1
        }}
        className="flex -ml-4 w-auto"
        columnClassName="pl-4"
      >
        {designs.map((design, index) => (
          <motion.div
            key={design.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="mb-4"
          >
            <div className="relative group rounded-lg overflow-hidden">
              <img
                src={design.imageUrl}
                alt={`Design variation ${index + 1}`}
                className="w-full h-auto rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="text-sm font-medium">Variation {index + 1}</p>
                  <p className="text-xs text-gray-300">{design.style} style</p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </Masonry>
    </motion.div>
  );
}