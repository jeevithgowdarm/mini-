import React from 'react';
import { motion } from 'framer-motion';

export function LoadingState() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center py-12 space-y-4"
    >
      <div className="relative">
        <div className="w-16 h-16 border-4 border-gray-700 border-t-emerald-400 rounded-full animate-spin" />
        <div className="absolute inset-0 w-16 h-16 border-4 border-emerald-400 border-t-transparent rounded-full animate-ping opacity-20" />
      </div>
      <div className="text-center">
        <p className="text-lg font-medium">Generating designs...</p>
        <p className="text-sm text-gray-400">This may take a few moments</p>
      </div>
    </motion.div>
  );
}