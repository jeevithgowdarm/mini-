import React from 'react';
import { motion } from 'framer-motion';
import type { RoomStyle } from '../types';

interface StyleSelectorProps {
  selectedStyle: RoomStyle | null;
  onStyleSelect: (style: RoomStyle) => void;
}

const styles: { id: RoomStyle; name: string; description: string }[] = [
  {
    id: 'modern',
    name: 'Modern',
    description: 'Clean lines with a contemporary feel'
  },
  {
    id: 'minimalist',
    name: 'Minimalist',
    description: 'Simple, uncluttered, and purposeful'
  },
  {
    id: 'scandinavian',
    name: 'Scandinavian',
    description: 'Light, airy, and functional design'
  },
  {
    id: 'industrial',
    name: 'Industrial',
    description: 'Raw materials with an urban edge'
  },
  {
    id: 'contemporary',
    name: 'Contemporary',
    description: 'Current trends with sophisticated touches'
  }
];

export function StyleSelector({ selectedStyle, onStyleSelect }: StyleSelectorProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
    >
      {styles.map((style) => (
        <motion.button
          key={style.id}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onStyleSelect(style.id)}
          className={`p-4 rounded-lg transition-colors ${
            selectedStyle === style.id
              ? 'bg-purple-500 text-white'
              : 'bg-gray-800 hover:bg-gray-700 text-gray-200'
          }`}
        >
          <h3 className="text-lg font-medium">{style.name}</h3>
          <p className="mt-1 text-sm opacity-80">{style.description}</p>
        </motion.button>
      ))}
    </motion.div>
  );
}